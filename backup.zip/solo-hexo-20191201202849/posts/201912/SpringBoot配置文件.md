title: Spring-Boot配置文件
date: '2019-12-01 19:50:28'
updated: '2019-12-01 19:52:12'
tags: [待分类]
permalink: /articles/2019/12/01/1575201028164.html
---
## Spring-Boot配置文件

#### Spring-Boot配置文件介绍
默认spring boot支持两种类型的配置文件，名字是固定的（代表全局配置文件）：


```
application.properties
application.yml
```

可以通过自定义的配置文件来复写默认的spring boot的配置。

配置文件的目录在 项目的 src main resource 目录下

#### 配置-yaml语法

application.yml

```yaml
properties:
  name: 'gary'
#  对象的写法
  friend:
    name: 'gary'
    age: 19
#  数组的写法
  student:
    - lisi
    - chaoyuan
    - nihao
#  map 和对象是一样的写法
  data:
    k1: aaa
    k2: bbb
    k3: ccc

```
> 这里数组和map的赋值不建议使用什么行内写法

#### 注入配置文件

```java
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

/**
 * @ConfigurationProperties 该注解是告诉 Spring boot，将本类的所有属性和配置文件中配置的值进行绑定
 * prefix 标识指定配置文件中的值
 *
 * 只有这个组件是容器中的组件，才能使用容器中的 @ConfigurationProperties 功能
 * 通过 @Component 注解将组件添加到容器中。
 *
 *
 */
@Component
@ConfigurationProperties(prefix = "properties")
public class Properties {

    private String name;
    private Friend friend;
    private List<String> student;
    Map<String, String> data;


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


    public Friend getFriend() {
        return friend;
    }

    public void setFriend(Friend friend) {
        this.friend = friend;
    }

    public List<String> getStudent() {
        return student;
    }

    public void setStudent(List<String> student) {
        this.student = student;
    }

    public Map<String, String> getData() {
        return data;
    }

    public void setData(Map<String, String> data) {
        this.data = data;
    }

    @Override
    public String toString() {
        return "Properties{" +
                "name='" + name + '\'' +
                ", friend=" + friend +
                ", student=" + student +
                ", data=" + data +
                '}';
    }
}
```

> 非常值得一提的是，该类必须复写 get 和 set 方法，否则将如法注入值


#### 运行测试

```java
@RunWith(SpringRunner.class)
@SpringBootTest
public class DemoApplicationTests {

    @Autowired
    Properties properties;

    @Test
    public void contextLoads() {
        System.out.println(properties.toString());
    }

}
```

#### 配置文件中文乱码问题

在项目配置中，编辑 Editor 中的  File Encodings 配置为 UTF-8 并勾选 转换为  asciii 码


#### application properties 的语法

>在使用之前请确保配置了注解
```java
@Component
@ConfigurationProperties(prefix = "properties")
```


```properties
properties.name='gary'
properties.friend.name=卢桂林
properties.friend.age=18
# 这种是list和数组的赋值
properties.student=ni,wo,ta
# 这种方式设置map
properties.data.k1=aaa
properties.data.k2=bbb
properties.data.k3=ccc
```






