title: Maven安装
date: '2019-12-01 19:47:31'
updated: '2019-12-01 19:47:31'
tags: [待分类]
permalink: /articles/2019/12/01/1575200851199.html
---
### Maven安装

#### Mac 平台安装Maven

到官网下载版本：http://maven.apache.org/download.cgi


配置好环境环境变量即可：

```bash
MAVEN_HOME=/Users/gary/LocalApplication/apache-maven-3.6.1
PATH=$PATH:$MAVEN_HOME/bin
export MAVEN_HOME
```

检查版本：

```bash
GarysMBP:conf gary$ mvn -v
Apache Maven 3.6.1 (d66c9c0b3152b2e69ee9bac180bb8fcc8e6af555; 2019-04-05T03:00:29+08:00)
Maven home: /Users/gary/LocalApplication/apache-maven-3.6.1
Java version: 1.8.0_144, vendor: Oracle Corporation, runtime: /Library/Java/JavaVirtualMachines/jdk1.8.0_144.jdk/Contents/Home/jre
Default locale: zh_CN, platform encoding: UTF-8
OS name: "mac os x", version: "10.14.5", arch: "x86_64", family: "mac"
```

#### 集成环境到InteliJ中


默认的buildtool中的Maven是`Bundled (Maven 3)`

我们选择默认的安装路径：`/Users/gary/LocalApplication/apache-maven-3.6.1`

同时这只 setting.xml 文件的路径：`/Users/gary/LocalApplication/apache-maven-3.6.1/conf/settings.xml`  

本地repository仓库路径：`/Users/gary/LocalApplication/apache-maven-3.6.1/repository`

